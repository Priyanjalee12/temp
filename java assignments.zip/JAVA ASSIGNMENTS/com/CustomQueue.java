package com;

class CustomQueue {
    private Object[] queue;
    private int front;
    private int rear;
    private int size;
    private int capacity;

    public CustomQueue(int capacity) {
        this.capacity = capacity;
        queue = new Object[capacity];
        front = 0;
        rear = -1;
        size = 0;
    }

    public void enqueue(Object item) {
        if (size == capacity) {
            System.out.println("Queue is full.");
            return;
        }
        rear++;
        queue[rear] = item;
        size++;
    }

    public Object dequeue() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return null;
        }
        Object item = queue[front];
        front++;
        size--;
        return item;
    }

    public Object peek() {
        if (isEmpty()) {
            System.out.println("Queue is empty.");
            return null;
        }
        return queue[front];
    }

    public boolean isEmpty() {
        return size == 0;
    }


    public static void main(String[] args) {
        CustomQueue queue = new CustomQueue(5);

        queue.enqueue("Hello");
        queue.enqueue(10);
        queue.enqueue("World");
        queue.enqueue(20);

        while (!queue.isEmpty()) {
            System.out.println(queue.dequeue());
        }
    }
}
