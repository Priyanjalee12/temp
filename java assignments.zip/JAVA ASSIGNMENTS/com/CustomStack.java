package com;

public class CustomStack
{
	
	    private int[] stack;
	    private int top;
	    private int capacity;

	    public CustomStack(int size) 
	    {
	        stack = new int[size];
	        capacity = size;
	        top = -1;
	    }

	    public void push(int value)
	    {
	        if (top == capacity - 1) 
	        {
	            System.out.println("Stack is full.");
	            return;
	        }
	        stack[++top] = value;
	    }

	    public int pop()
	    {
	        if (isEmpty()) 
	        {
	            System.out.println("Stack is empty.");
	            return -1;
	        }
	        return stack[top--];
	    }

	    public int peek()
	    {
	        if (isEmpty()) 
	        {
	            System.out.println("Stack is empty.");
	            return -1;
	        }
	        return stack[top];
	    }

	    public boolean isEmpty() 
	    {
	        return top == -1;
	    }
	

	 
	    public static void main(String[] args) {
	        CustomStack stack = new CustomStack(3);

	        stack.push(5);
	        stack.push(10);
	        stack.push(15);
//	        stack.pop();
//	        stack.pop();
//	        stack.pop();
//	        stack.pop();

	        while (!stack.isEmpty()) {
	            System.out.println(stack.pop());
	        }
	    }
}	

