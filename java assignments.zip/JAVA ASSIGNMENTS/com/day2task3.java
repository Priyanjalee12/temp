package com;

public class day2task3
{
	public static void main(String [] args)
	{
		int a=10;
		int b=0;
		try {
		
		int res=a/b;
		
		}
		catch(Exception e)
		{
			System.out.println("zero should not be in the denominator"+e.getMessage());
		}
		
	}
}
