package com;

public class day4task1 {
	    private int rows;
	    private int columns;
	    private int[][] m;

	    public day4task1(int rows, int columns) {
	        this.rows = rows;
	        this.columns = columns;
	        this.m = new int[rows][columns];
	    }

	    public void matrix(int[][] values) {
	        for (int i = 0; i < rows; i++)
	        {
	            for (int j = 0; j < columns; j++) 
	            {
	               m[i][j] = values[i][j];
	               System.out.print(m[i][j] + " ");
	            }
	            System.out.println();	        }
	    }



	    public static void main(String[] args) {
	        day4task1 mat= new day4task1(3, 3);
	        int[][] values = {{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
	        mat.matrix(values);
//	        
	    }
	}

