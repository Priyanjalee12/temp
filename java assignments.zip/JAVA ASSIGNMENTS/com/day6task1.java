package com;
import java.util.*;
public class day6task1 
{
	public static void removeEverySecondElement(List<Object> list) {
	        for (int i = 1; i < list.size(); i++) {
	            list.remove(i);
	            
	        }
	        System.out.println(list);
	    }

	    public static void main(String[] args) {
	        List<Object> myList = new ArrayList<>();
	        myList.add("Apple");
	        myList.add("Banana");
	        myList.add("Cherry");
	        myList.add("Date");
	        myList.add("Fig");
	        myList.add("anjali");
	        myList.add("tej");

	        removeEverySecondElement(myList);
	    }
	}

