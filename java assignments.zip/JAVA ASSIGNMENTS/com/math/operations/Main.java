package com.math.operations;

public class Main {
	 public static void main(String[] args) {
	        if (args.length != 3) {
	            System.out.println("Usage: java Main operation operand1 operand2");
	            System.exit(1);
	        }
	        class Addition {
	        	 public static double add(double a, double b) {
	        	     return a + b;
	        	 }
	        	}
	      class Subtraction {
	            public static double subtract(double a, double b) {
	                return a - b;
	            }
	        }
	   class Multiplication {
	          public static double multiply(double a, double b) {
	              return a * b;
	          }
	      }
	 class Division {
	       public static double divide(double a, double b) {
	           if (b == 0) {
	               System.out.println("Error: Division by zero!");
	               System.exit(1);
	           }
	           return a / b;
	       }
	   }


	        String operation = args[0];
	        double operand1 = Double.parseDouble(args[1]);
	        double operand2 = Double.parseDouble(args[2]);
	        double result = 0;

	        switch (operation) {
	            case "add":
	                result = Addition.add(operand1, operand2);
	                break;
	            case "subtract":
	                result = Subtraction.subtract(operand1, operand2);
	                break;
	            case "multiply":
	                result = Multiplication.multiply(operand1, operand2);
	                break;
	            case "divide":
	                result = Division.divide(operand1, operand2);
	                break;
	            default:
	                System.out.println("Invalid operation. Please choose from: add, subtract, multiply, divide");
	                System.exit(1);
	        }

	        System.out.println("Result: " + result);
	    }

}
