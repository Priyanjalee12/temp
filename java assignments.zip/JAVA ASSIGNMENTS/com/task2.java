package com;

public class task2 {
	
	    public static void main(String[] args) {
	        if (args.length != 3) {
	            System.out.println("Usage: java Calculator operation operand1 operand2");
	            System.exit(1);
	        }

	        String operation = args[0];
	        double operand1 = Double.parseDouble(args[1]);
	        double operand2 = Double.parseDouble(args[2]);
	        double result = 0;

	        switch (operation) {
	            case "add":
	                result = add(operand1, operand2);
	                break;
	            case "subtract":
	                result = subtract(operand1, operand2);
	                break;
	            case "multiply":
	                result = multiply(operand1, operand2);
	                break;
	            case "divide":
	                result = divide(operand1, operand2);
	                break;
	            default:
	                System.out.println("Invalid operation. Please choose from: add, subtract, multiply, divide");
	                System.exit(1);
	        }

	        System.out.println("Result: " + result);
	    }

	    public static double add(double a, double b) {
	        return a + b;
	    }

	    public static double subtract(double a, double b) {
	        return a - b;
	    }

	    public static double multiply(double a, double b) {
	        return a * b;
	    }

	    public static double divide(double a, double b) {
	        if (b == 0) {
	            System.out.println("Error: Division by zero!");
	            System.exit(1);
	        }
	        return a / b;
	    }
	}



