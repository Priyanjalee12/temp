package com;
import java.util.*;

public class task3 {

	public static void main(String [] args)
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the number");
		int no=sc.nextInt();
		int c=0;
		for(int i=1;i<=no;i++)
		{
			if(no%i==0)
			{
				c++;
			}
		}
		if(c==2)
		{
			System.out.println("it is prime number");
		}
		else
		{
			System.out.println("it is not prime");
		}
		
	}

}
