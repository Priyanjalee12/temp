package com;

public class task4 
{
	public static void main(String [] args)
	{
		int [] arr=new int[5];
		for(int i=0;i<5;i++)
		{
			arr[i]=i+1;
		}
		System.out.println("array is");
		for(int j=0;j<arr.length;j++)
		{
			System.out.print(j+" ");
		}
		System.out.println(" ");
		System.out.println("reverse array is:");
		for(int k=arr.length;k>0;k--)
		{
			System.out.print(k+" ");
		}
	
	}
}
