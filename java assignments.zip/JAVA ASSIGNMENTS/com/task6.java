package com;

public class task6 
{
	public static int sumArray(int[] arr, int n) {
	        
	        if (n == 0) {
	            return 0;
	        }
	        return arr[n - 1] + sumArray(arr, n - 1);
	    }

	    public static void main(String[] args) {
	        int[] arr = {1, 2, 3, 4, 5};
	        int sum = sumArray(arr, arr.length);
	        System.out.println("Array: [1, 2, 3, 4, 5]");
	        System.out.println("Sum of elements: " + sum);
	    }
	}



