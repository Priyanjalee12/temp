package com;
import java.util.*;
public class task7a 
{
	public static void bruteForceSort(int[] arr) {
	        int n = arr.length;
	        for (int i = 0; i < n - 1; i++) {
	            for (int j = i + 1; j < n; j++) {
	                if (arr[i] > arr[j]) {
	                    
	                    int temp = arr[i];
	                    arr[i] = arr[j];
	                    arr[j] = temp;
	                }
	            }
	        }
	    }

	    public static void main(String[] args) {
	        int[] arr = initializeArray(10); // Initialize array with 10 random elements
	        System.out.println("Original Array:");
	        printArray(arr);
	        
	        bruteForceSort(arr);

	        System.out.println("\nSorted Array:");
	        printArray(arr);
	    }

	    public static int[] initializeArray(int size) {
	        int[] arr = new int[size];
	        Random random = new Random();
	        for (int i = 0; i < size; i++) {
	            arr[i] = random.nextInt(100);
	        }
	        return arr;
	    }

	    public static void printArray(int[] arr) {
	        for (int num : arr) {
	            System.out.print(num + " ");
	        }
	        System.out.println();
	    }
	}


