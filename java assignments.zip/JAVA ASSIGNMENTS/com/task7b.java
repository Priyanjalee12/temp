package com;

public class task7b 
{


	    public static int performLinearSearch(int[] arr, int target) {
	        for (int i = 0; i < arr.length; i++) {
	            if (arr[i] == target) {
	                return i; 
	            }
	        }
	        return -1; 
	    }

	    public static void main(String[] args) {
	        int[] arr = {5, 10, 15, 20, 25};
	        int target = 15;
	        System.out.println("Array: [5, 10, 15, 20, 25]");
	        System.out.println("Target: " + target);
	        int index = performLinearSearch(arr, target);
	        if (index != -1) {
	            System.out.println("Element found at index: " + index);
	        } else {
	            System.out.println("Element not found in the array.");
	        }
	    }
	}


