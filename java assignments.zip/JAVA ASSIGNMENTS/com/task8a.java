package com;
import java.util.*;;
public class task8a {
	
 public static int[] sliceArray(int[] arr, int start, int end) {
	       
	        if (start < 0 || end < start || end > arr.length) {
	            throw new IllegalArgumentException("Invalid start or end index");
	        }
	        int size = end - start;
	     int[] result = new int[size];
	       System.arraycopy(arr, start, result, 0, size);
	       return result;
	    }
            public static void main(String[] args) {
	        int[] arr = {1, 2, 3, 4, 5, 6, 7, 8, 9};
	        int start = 2;
	        int end = 6;
	        
	        System.out.println("Original Array: " + Arrays.toString(arr));
	        System.out.println("Start Index: " + start);
	        System.out.println("End Index: " + end);
	        
	        int[] slicedArray = sliceArray(arr, start, end);
	        System.out.println("Sliced Array: " + Arrays.toString(slicedArray));
	    
	}


}
