package com;

public class task8b {
	
	    public static int fib(int n) {
	        if (n <= 1) {
	            return n;
	        } else {
	            return fib(n - 1) + fib(n - 2);
	        }
	    }

	    public static void store(int n, int[] arr, int index) {
	        if (index < n) {
	            arr[index] = fib(index);
	            store(n, arr, index + 1);
	        }
	    }

	    public static void main(String[] args) {
	        int n = 7; 
	        int[] arr = new int[n];

	        store(n, arr, 0);

	        System.out.println("First " + n + " elements of Fibonacci sequence:");
	        for (int i = 0; i < n; i++) {
	            System.out.print(arr[i] + " ");
	        }

	        int nthElement = fib(n - 1);
	        System.out.println("\n\nThe " + n + "th element of Fibonacci sequence is: " + nthElement);
	    }
	}


