package com;

public class task9 {
	    public static String extractMiddleSubstring(String str1, String str2, int length) {
	        if (str1 == null || str2 == null || str1.isEmpty() || str2.isEmpty()) {
	            return "Both input strings must not be empty";
	        }

	        String concatenated = str1.concat(str2);
	        String reversed = new StringBuilder(concatenated).reverse().toString();

	        if (length >= reversed.length()) {
	            return reversed;
	        }

	        int start = (reversed.length() - length) / 2;
	        int end = start + length;

	        return reversed.substring(start, end);
	    }

	    public static void main(String[] args) {
	        String str1 = "Hello";
	        String str2 = "World";
	        int length = 5;

	        String result = extractMiddleSubstring(str1, str2, length);
	        System.out.println("Middle substring of length " + length + " from the reversed concatenation: " + result);
	    }
	}


